# hr_cv_screening
|file | Description|
| --- | --- |
|app.py | Basic code of the application used for test|
| to-do-prompting.docx | to track or add any new ideas in the prompt |
| CV-scoring-initial-stage.csv | Initial scores of the resumes for reference |

|function | Description |
| --- | --- |
| load_file | used to extract text from pdf,docx |
| extract_score | Evaluates resume and provides the output as JSON |

**steps to run the file

*1. Install the required packages using  the following command
        pip install -r requirements.txt
*2. Run the python file with the following command
        python app.py
        
**Model used: GPT-3.5-turbo-0125
**Model parameter Temperature: 0.7

        
**Note:
1. Since this is a basic app please make sure you have given the correct paths to the resumes while testing it out.
2. Please don't delete anything in the to-do-prompting and also in the csv file,feel free to add your comments in a new line or column.
     

