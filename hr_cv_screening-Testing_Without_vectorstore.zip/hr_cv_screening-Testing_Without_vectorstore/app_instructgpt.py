from langchain_community.document_loaders import UnstructuredFileLoader
from langchain_core.prompts import PromptTemplate
from langchain_community.callbacks import get_openai_callback
from langchain_openai import OpenAI
import fitz
import os

OPENAI_API_KEY="api key" #replace with openai api key
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Install dependencies if you face issues with the unstrutured library
# !brew install poppler
# !brew install tesseract

def load_file(filepath):
    """ 
        Loads the contents of a file at the given filepath, handling both .docx and .pdf file formats.
        
        Args:
            filepath (str): The path to the file to be loaded.
        
        Returns:
            str: The text contents of the file.
    """
    if filepath.endswith(".docx"):
        loader = UnstructuredFileLoader(filepath)
        docs=loader.load()
        text=""
        for doc in docs:
            text+=doc.page_content
        return text
    elif filepath.endswith(".pdf"):
        doc = fitz.open(filepath)
        total_text=""
        for page in doc:
            text = page.get_text()
            total_text+=text
        return total_text

def extract_score(docs,jd):
    """
    Evaluates a resume based on a given job description and returns a JSON object with the candidate's scores.
    
    Args:
        docs (str): The text content of the candidate's resume.
        jd (str): The text content of the job description.
    
    Returns:
        dict: A JSON object containing the candidate's scores for skills, education, projects, work experience, and overall matching score.
    """
    template = """
    You are an expert in talent acquisition, skilled at determining the best candidate for a particular job based on the job description provided.
    Analyze the job description and identify the most important skills and experience required for the job and use these to analyse the resume.
    Job description:{jd}
    Resume:{resume}
    Your primary task is to evaluate the resume of the candidate based on the specified criteria.
    Criteria:
    Skills: Evaluate the relevance, variety, and depth of the skills listed in the resume and give a score out of 20.\
    Education: Evaluate the level of education, relevance to the field, and academic achievements and give a score out of 10.\
    Projects: Evaluate the complexity, impact, and relevance of the projects mentioned that are matching the job description and give a score out of 40,\
    Work Experience: Evaluate the relevance, duration, and quality of the work experience listed and give a score out of 30.\
    Overall Matching Score: Evaluate the candidate's suitability for the job based on the given job description and provide a Score out of 100.
    Format the output as JSON and include the name of the candidate as "Name" in the output and with the following keys
    Skills
    Education
    Projects
    Work Experience
    Overall Matching Score
    """
    
    prompt_template = PromptTemplate(input_variables=["jd","resume"],template=template)
    llm=OpenAI(model='gpt-3.5-turbo-instruct',temperature=0.7)
    chain = prompt_template | llm 
    with get_openai_callback as cb:
        output = chain.invoke(input={"resume":docs,"jd":jd})
        print("Tokens_utilised",cb.total_tokens)
        print("Total_cost",cb.total_cost)
    return output

def main():
    """
    Generates a CSV file containing the evaluation scores for a set of resumes based on a given job description.
    
    The `main()` function loads a set of resume files, extracts the text content from each resume, and evaluates the candidate's suitability for the job based on the provided job description. The evaluation scores are stored in a JSON format and then converted to a CSV file.
    
    The CSV file contains the following columns:
    - Name: The name of the candidate
    - Skills Score: The score for the candidate's skills
    - Education Score: The score for the candidate's education
    - Projects Score: The score for the candidate's projects
    - Work Experience Score: The score for the candidate's work experience
    - Overall Matching Score: The overall score for the candidate's suitability for the job
    
    The CSV file is saved to the file 'scoring_new.csv' in the current directory.
    """
    resumes=["/Users/kranthivardhankurumindla/Documents/HR_usecase/Aajin Roy.pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Adarsh.pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Akhil_Rajan_Resume.pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/midhunresume.pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_ArvindKumarJangid[12y_0m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_ChandrajeetPratapSingh[5y_0m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_DEEPAMERLINDIXONK[4y_3m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_JeevanDhadge[7y_2m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_KUNALTAJANE[5y_1m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_ParagKumarJain[5y_9m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_RamandeepBains[5y_1m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_RohitKumarGupta[8y_0m].pdf",
            "/Users/kranthivardhankurumindla/Documents/HR_usecase/Naukri_ShephaliGupta[7y_6m].pdf"
        ]
    
    jd=load_file("/Users/kranthivardhankurumindla/Documents/HR_usecase/Full-stack Data Scientist_Job Description_v2.docx")
    for resume in resumes:
        docs=load_file(resume)
        Scores=extract_score(docs,jd)
        print(Scores)
        


if __name__ == "__main__":
    main()  

